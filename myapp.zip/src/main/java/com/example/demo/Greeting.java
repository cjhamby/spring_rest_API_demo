package com.example.demo;


public record Greeting(long id, String content) {
}